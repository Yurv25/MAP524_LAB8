package ict.seneca.testcoursesprovider;


import android.content.ContentValues;
import android.content.CursorLoader;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends ActionBarActivity {
    private final String CONTENT_URI ="content://seneca.ict.provider.CoursesProvider/courses";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }

    public void addTitle(View view){
        ContentValues values = new ContentValues();
        values.put("title", ((EditText)
                findViewById(R.id.txtTitle)).getText().toString());
        values.put("code", ((EditText)
                findViewById(R.id.txtcode)).getText().toString());
        values.put("room", ((EditText)
                findViewById(R.id.txtroom)).getText().toString());

        Uri uri = getContentResolver().insert(Uri.parse(CONTENT_URI), values);

        Toast.makeText(getBaseContext(), uri.toString(),
                Toast.LENGTH_LONG).show();
    }

    public void retrieveTitles(View view){

        Uri allTitles = Uri.parse(CONTENT_URI);

        Cursor c;
        if (android.os.Build.VERSION.SDK_INT <11) {
            //---before Honeycomb---
            c = managedQuery(allTitles, null, null, null,
                    "title desc");
        } else {
            //---Honeycomb and later---
            CursorLoader cursorLoader = new CursorLoader(
                    this,
                    allTitles, null, null, null,
                    "title desc");
            c = cursorLoader.loadInBackground();
        }

        List<String> codes = new ArrayList<>();
        if (c.moveToFirst()) {
            do{
                codes.add(
                        c.getString(c.getColumnIndex("_id")) + ", "
                        + c.getString(c.getColumnIndex("title")) + ", "
                        + c.getString(c.getColumnIndex("code")) + ", "
                        + c.getString(c.getColumnIndex("room")));
            } while (c.moveToNext());
        }

        ListAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1, codes);
        ListView listView = (ListView) findViewById(R.id.listCourses);
        listView.setAdapter(adapter);

    }

}